def sys_score(sys_info):
    component_vulns = {}
    for component in sys_info["components"].keys():
        component_vulns[component] = []
    for vuln in sys_info["vulnerabilities"].keys():
        for component in sys_info["vulnerabilities"][vuln]["components"].keys():
            component_vulns[component].append(sys_info["vulnerabilities"][vuln]["score"])
    component_scores = {}
    for component in sys_info["components"].keys():
        dependency_branch(sys_info, component_vulns, component_scores, component)
    functionality_scores = {}
    for functionality in sys_info["functionalities"].keys():
        sub_scores = sorted([solved[component] for component in sys_info["functionalities"][functionality]["components"]], reverse=True)
        functitonality_scores[functionality] = sum([sub_score / (i + 1) for i, sub_score in enumerate(sub_scores)])
    sum([functionality_score[functionality] * sys_info["functionalities"][functionality]["score"] for functionality in sys_info["functionalities"].keys()])

def dependency_branch(sys_info, component_vulns, solved, component):
    if component in solved.keys():
        return solved[component]

    if len(sys_info["components"][component]["dependencies"]) == 0:
        sub_scores = [0.0]
    else:
        sub_scores = sorted([dependency_branch(sys_info, component_vulns, solved, subcomponent) for subcomponent in sys_info["components"][component]["dependencies"]], reverse=True)
    sum_adjusted_sub = sum([sub_score / (i + 1) for i, sub_score in enumerate(sub_scores)])
    component_scores = sorted([sum_adjusted_sub] + component_vulns[component], reverse=True)
    sum_adjusted_component = sum([component_score / (i + 1) for i, component_score in enumerate(component_scores)])
    solved[component] = sum_adjusted_component
