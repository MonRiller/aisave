import os

__version__ = '0.1'
__author__ = 'Ronald Miller'
__license__ = 'MIT'

base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
