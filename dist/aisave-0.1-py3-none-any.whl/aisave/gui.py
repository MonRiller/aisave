import os, json
import customtkinter as ctk
from aisave import base
from aisave.crypto import load_info, save_info
from aisave.cve import update_cves
from PIL import Image


def get_users():
    return [file[:-4] for file in os.listdir(os.path.join(base, "data")) if file[-4:] == ".enc"]

class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("AISAVE")
        self.geometry("1400x800")
        self.grid_columnconfigure((0, 1, 2), weight=1)

        self.settings = json.loads(open(os.path.join(base, "data", "settings.json"), 'r').read())
        self.apply_settings()
        # <a href="https://www.flaticon.com/free-icons/settings" title="settings icons">Settings icons created by See Icons - Flaticon</a>
        cog = Image.open(os.path.join(base, "data", "settings.png"))
        cog_ctk = ctk.CTkImage(cog, cog, size=(30, 30))
        self.settings_button = ctk.CTkButton(self, image=cog_ctk, text="", width=40, height=40, fg_color="transparent", command=lambda: SettingsPopup(self), hover=False)
        self.settings_button.grid(row=0, column=2, padx=10, pady=10, sticky="ne")
        self.spacer = ctk.CTkFrame(self, width=40, height=40, fg_color="transparent")
        self.spacer.grid(row=0, column=0, padx=10, pady=10, sticky="nw")

        self.page = None
        self.show_page(LoginFrame(self))

    def apply_settings(self):
        ctk.set_appearance_mode(self.settings["theme"])
        ctk.set_default_color_theme(self.settings["color"])
        with open(os.path.join(base, "data", "settings.json"), 'w') as file:
            file.write(json.dumps(self.settings))

    def show_page(self, page):
        if self.page is not None:
            self.page.destroy()
        self.page = page
        page.grid(row=0, column=1, padx=20, pady=20, sticky="n")

    def login(self, username, password):
        if username not in get_users():
            self.page.warning.configure(text="User does not exist")
            return

        info = load_info(username, password)
        if info is None:
            self.page.warning.configure(text="Decryption error")
            return

        self.show_page(MainFrame(self, info))

    def register(self, username, password, repeat):
        if username == "" or username is None:
            self.page.warning.configure(text="Username must not be empty")
            return

        if password == "" or password is None:
            self.page.warning.configure(text="Password must not be empty")
            return

        if username in get_users():
            self.page.warning.configure(text="User already exists")
            return

        if password != repeat:
            self.page.warning.configure(text="Passwords do not match")
            return

        info = {"username":username, "password":password}
        save_info(info)
        self.show_page(MainFrame(self, info))

class ReturnButton(ctk.CTkButton):
    def __init__(self, master, *args, **kwargs):
        super().__init__(master, *args, **kwargs)
        if self.cget("command") != None:
            self.fg_hold = self.cget("fg_color")
            self.bind("<Return>", lambda event: self.cget("command")())
            self.bind("<FocusIn>", lambda event: self.configure(fg_color=self.cget("hover_color")))
            self.bind("<FocusOut>", lambda event: self.configure(fg_color=self.fg_hold))

class SettingsPopup(ctk.CTkToplevel):
    def __init__(self, master, *args, **kwargs):
        super().__init__(master, *args, **kwargs)
        self.title("Settings")
        self.grid_columnconfigure((0, 1), weight=1)

        self.style_label = ctk.CTkLabel(self, text="Style", font=("Roboto", 24))
        self.style_label.grid(row=0, column=0, columnspan=2, padx=20, pady=(20, 10), sticky="w")

        self.style_frame = ctk.CTkFrame(self)
        self.style_frame.grid(row=1, column=0, columnspan=2, padx=20, sticky="new")

        self.theme_label = ctk.CTkLabel(self.style_frame, text="Theme:")
        self.theme_label.grid(row=0, column=0, padx=(20, 10), pady=10, sticky="w")

        self.theme = ctk.CTkOptionMenu(self.style_frame, values=["light", "dark"], command=lambda choice: master.settings.update({"theme": choice}))
        self.theme.set(master.settings["theme"])
        self.theme.grid(row=0, column=1, pady=10, sticky="e")

        self.color_label = ctk.CTkLabel(self.style_frame, text="Color:")
        self.color_label.grid(row=1, column=0, padx=(20, 10), pady=10, sticky="w")

        self.color = ctk.CTkOptionMenu(self.style_frame, values=["blue", "dark-blue", "green"], command=lambda choice: master.settings.update({"color": choice}))
        self.color.set(master.settings["color"])
        self.color.grid(row=1, column=1, pady=10, sticky="e")

        self.apply_button = ReturnButton(self, text="Apply", command=master.apply_settings)
        self.apply_button.grid(row=2, column=0, padx=(20, 10), pady=10, sticky="ew")

        self.cancel_button = ReturnButton(self, text="Cancel", command=self.destroy)
        self.cancel_button.grid(row=2, column=1, padx=(10, 20), pady=10, sticky="ew")

        self.cve_label = ctk.CTkLabel(self, text="CVEs", font=("Roboto", 24))
        self.cve_label.grid(row=3, column=0, columnspan=2, padx=20, pady=(20, 10), sticky="w")

        self.cve_button = ReturnButton(self, text="Update CVE database", command=update_cves)
        self.cve_button.grid(row=4, column=0, columnspan=2, padx=20, pady=10, sticky="ew")

class LoginFrame(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master)

        self.title = ctk.CTkLabel(self, text="Login", font=("Roboto", 24))
        self.title.grid(row=0, column=0, sticky="ew", padx=20, pady=20, columnspan=2)

        self.username_entry = ctk.CTkEntry(self, placeholder_text="Username", width=200)
        self.username_entry.grid(row=1, column=0, sticky="ew", padx=20, pady=10, columnspan=2)

        self.password_entry = ctk.CTkEntry(self, placeholder_text="Password", show="*", width=200)
        self.password_entry.grid(row=2, column=0, sticky="ew", padx=20, pady=10, columnspan=2)

        login_lambda = lambda event=None: master.login(self.username_entry.get(), self.password_entry.get())
        self.username_entry.bind("<Return>", login_lambda)
        self.password_entry.bind("<Return>", login_lambda)

        self.login_button = ReturnButton(self, text="Login", command=login_lambda)
        self.login_button.grid(row=3, column=0, sticky="ew", padx=(20, 10), pady=(10, 0))

        self.register_button= ReturnButton(self, text="New user", command=lambda: master.show_page(RegisterFrame(master)))
        self.register_button.grid(row=3, column=1, sticky="ew", padx=(10, 20), pady=(10, 0))

        self.warning = ctk.CTkLabel(self, text="", text_color="red")
        self.warning.grid(row=4, column=0, sticky="ew", padx=20, pady=10, columnspan=2)

class RegisterFrame(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master)

        self.title = ctk.CTkLabel(self, text="Register", font=("Roboto", 24))
        self.title.grid(row=0, column=0, sticky="ew", padx=20, pady=20, columnspan=2)

        self.username_entry = ctk.CTkEntry(self, placeholder_text="Username", width=200)
        self.username_entry.grid(row=1, column=0, sticky="ew", padx=20, pady=10, columnspan=2)

        self.password_entry = ctk.CTkEntry(self, placeholder_text="Password", show="*", width=200)
        self.password_entry.grid(row=2, column=0, sticky="ew", padx=20, pady=10, columnspan=2)

        self.repeat_entry = ctk.CTkEntry(self, placeholder_text="Repeat password", show="*", width=200)
        self.repeat_entry.grid(row=3, column=0, sticky="ew", padx=20, pady=10, columnspan=2)

        register_lambda = lambda event=None: master.register(self.username_entry.get(), self.password_entry.get(), self.repeat_entry.get())
        self.username_entry.bind("<Return>", register_lambda)
        self.password_entry.bind("<Return>", register_lambda)
        self.repeat_entry.bind("<Return>", register_lambda)

        self.register_button= ReturnButton(self, text="Register", command=register_lambda)
        self.register_button.grid(row=4, column=0, sticky="ew", padx=(20, 10), pady=(10, 0))

        self.login_button = ReturnButton(self, text="Return to login", command=lambda: master.show_page(LoginFrame(master)))
        self.login_button.grid(row=4, column=1, sticky="ew", padx=(10, 20), pady=(10, 0))

        self.warning = ctk.CTkLabel(self, text="", text_color="red")
        self.warning.grid(row=5, column=0, sticky="ew", padx=20, pady=10, columnspan=2)

class MainFrame(ctk.CTkFrame):
    def __init__(self, master, info):
        super().__init__(master)

        self.title = ctk.CTkLabel(self, text=info["username"])
        self.title.grid(row=0, column=0, sticky="ew", padx=20, pady=20)

        self.return_button = ReturnButton(self, text="Return", command=lambda: master.show_page(LoginFrame(master)))
        self.return_button.grid(row=1, column=0, sticky="ew", padx=20, pady=10)

def main():
    app = App()
    app.mainloop()

if __name__ == "__main__":
    main()
