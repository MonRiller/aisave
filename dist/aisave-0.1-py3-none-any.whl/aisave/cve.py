def update_cves():
    print("HERE")
